package fan.kevindebruyne.big.LibrarySystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrarySystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
